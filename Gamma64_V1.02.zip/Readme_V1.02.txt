Gamma64 V1.02 by iProgramInCpp - README!

What's New in this build?
- Optimizations, ROM is now 8 megabytes flat
- Real hardware no longer crashes in GH and WF
- Removed fileselect background, it started causing issues on real HW.
- Previous V1.02 (short-lived one) has a pause bug that is fixed now.
