function setup() {
    createCanvas(300,300);
  // put setup code here
  // createCanvas(window.innerWidth, window.innerHeight);
}

function draw() {
  // put drawing code here
  background(129,203,255);
  triangle(0,0,231,231,0,231); // Should produce a right triangle
}