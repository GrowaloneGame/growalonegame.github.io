If you plan on modding Growalone, here's what you need to convert textures to PNG.

TExtract - extracts ALL content
TerrariaXNB2PNG - extracts one file

These tools are designed for Terraria, but they have been tested and work on this, so please let me know if you find some things weird.
To add an item, you need:
- Skills
- Textures (*.xnb)
- Dedication
- and a way to get it and check it out.

Modding the EXE is a bit more complicated, as you'll need to recreate the project. Here's how to do it:

* Create a Windows game (Monogame Windows OpenGL Project)
* Put all the source files in the main project (where Program.cs is)
* Change program.cs to run an instance of Growalone
* use TExtract to extract all sprites
* put them in Content
* DONE! It's that easy! There is no mod loader (yet) because it is way harder to implement than you think.
If anyone can make a client that can accept this, email growalonegame@gmail.com!