# Gamma64 Prototype Release

!! Running these will _NOT_ mess up your saves on the released version of Gamma64. !!

!! Note. These are PATCH files, that must be applied to the US Z64 version of Super Mario 64. (The file name is usually "Super Mario 64 (U) [!].z64" or "sm64.us.z64". !!

It has been almost 2 years since Gamma64 first released to the public! To celebrate this occasion, I have decided to release a couple of prototypes to the public.

The prototypes' ROM header (with the exception of V0.02) is "SUPERMARIO64 GAMMA64".
The released ROM's header is "SUPERMARlO64 GAMMA64" (notice the small L in the place of the I). This change was done to prevent the Gamma64 demo released in January 2021 from messing up saves on the release builds.

This archive features, in total, 6 prototypes.

The new prototypes are:
+	Gamma64_build_V0.18.z64

	Built on October 28th, 2020.
	This build features the first import of the castle grounds.
	To access the level select menu, simply attempt to start the game as normal.

+	Gamma64_build_V0.433.z64

	Built on May 2nd, 2021, after V0.43, but before V0.44.
	This build features the very first version of the final space level. To access it, go to stage 21.
	This build also features the mystical 2D level. To access it, go to stage 35.
	To access the level select, hold C-Left + C-Right + Z, and press START, on the Mario face screen.

+	Gamma64_build_V0.02.z64

	Built on September 2nd, 2020.
	This build changes only one thing from the base game -- the player model. That's all! It's the
	"Play the vanilla game as Luigi" ROM.

Prototypes that have been leaked:
+	Gamma64_build_V0.23.z64
+	Gamma64_build_V0.33.z64
+	Gamma64_build_V0.34.z64

I hope you will enjoy them, as much as I enjoyed making this hack. Thanks!
- iProgramInCpp
