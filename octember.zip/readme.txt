The Octember Project Release!! 

NOTE: You *must* patch with a JP V1.0 release of SM64 (as Z64). 
Its sha1 hash: 8a20a5c83d6ceb0f0506cfc9fa20d8f438cafe51

To get a Z64 of SM64JP off of the internet (if you can't find a Z64 online), download any old ROM (so long as it's not an executable etc, any old *.n64 or *.z64 would do), and use this tool (https://hack64.net/tools/swapper.php) or Tool64 to turn it into a *.z64. 
To patch the ROM into The Octember Project, either use Flips, or https://hack64.net/tools/patcher.php, choose your JP version, and the patch. **DO NOT** check "Skip Checksums", you will end up with an unplayable rom.

When you're done patching the hack, enjoy!!!

-- iProgramInCpp